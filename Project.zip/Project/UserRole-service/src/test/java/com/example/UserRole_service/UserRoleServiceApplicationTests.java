package com.example.UserRole_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRoleServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
