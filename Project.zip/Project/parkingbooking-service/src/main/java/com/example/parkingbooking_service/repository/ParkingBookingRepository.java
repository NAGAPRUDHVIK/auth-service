package com.example.parkingbooking_service.repository;


import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.parkingbooking_service.repository.entity.ParkingBookingEntity;

import feign.Param;

@Repository
public interface ParkingBookingRepository extends JpaRepository<ParkingBookingEntity, Integer> {
	
	List<ParkingBookingEntity> findByParkingIdAndParkingBookingDate(int parkingId, LocalDate parkingBookingDate);
	
	@Query("SELECT p FROM ParkingBookingEntity p WHERE p.parkingId = :parkingId " +
	           "AND p.parkingBookingDate = :bookingDate " +
	           "AND ((p.startTime < :endTime AND p.endTime > :startTime))")
	    List<ParkingBookingEntity> findOverlappingBookings(
	            @Param("parkingId") int parkingId,
	            @Param("bookingDate") LocalDate bookingDate,
	            @Param("startTime") LocalTime startTime,
	            @Param("endTime") LocalTime endTime);
}
	
//	List<ParkingBookingEntity> findByParkingIdAndParkingBookingDateAndStartTimeAndEndTime(
//            int parkingId, LocalDate bookingDate, LocalTime startTime, LocalTime endTime);
	

 
