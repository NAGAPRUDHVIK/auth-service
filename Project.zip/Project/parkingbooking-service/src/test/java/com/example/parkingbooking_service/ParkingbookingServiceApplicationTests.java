package com.example.parkingbooking_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingbookingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
