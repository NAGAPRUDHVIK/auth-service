package com.example.parking_service.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class ParkingDto {
	
	private int parkingId;
    private String parkingNumber;
    private String parkingBuilding;
    private String parkingFloor;
    private String parkingType;  // Can be 2-wheeler or 4-wheeler
    private boolean parkingAvailable;

}
